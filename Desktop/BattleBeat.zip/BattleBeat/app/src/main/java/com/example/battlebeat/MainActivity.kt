package com.example.battlebeat

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.battlebeat.ui.theme.BattleBeatTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

class MainActivity : ComponentActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var audioFilePath: String = ""
    private var selectedBeat: String = ""
    private var selectedIndex by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BattleBeatTheme {
                MainScreen()
            }
        }
    }

    @Composable
    fun MainScreen() {
        var expanded by remember { mutableStateOf(false) }
        var isPressed by remember { mutableStateOf(false) }
        val snackbarHostState = remember { SnackbarHostState() }
        val beats = listOf("Beat 1", "Beat 2", "Beat 3")
        val backgroundColor by animateColorAsState(
            targetValue = if (isPressed) Color.Gray else Color.Black
        )
        val scope = rememberCoroutineScope()

        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.background_image),
                contentDescription = null,
                contentScale = ContentScale.Cover, // Correcto
                modifier = Modifier.fillMaxSize()
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Dropdown para seleccionar la base
                Button(
                    onClick = { expanded = !expanded },
                    colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Text(text = beats[selectedIndex], color = Color.Red)
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    beats.forEachIndexed { index, beat ->
                        DropdownMenuItem(
                            text = { Text(text = beat) },
                            onClick = {
                                selectedIndex = index
                                selectedBeat = beat
                                expanded = false
                            }
                        )
                    }
                }

                // Botón para reproducir base
                Button(
                    onClick = {
                        isPressed = !isPressed
                        scope.launch {
                            snackbarHostState.showSnackbar("Reproduciendo base...")
                        }
                        playBeat(beats[selectedIndex])
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Text(text = "Reproducir Base", color = Color.Red)
                }

                // Botón para detener base
                Button(
                    onClick = {
                        stopAudio()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Text(text = "Detener Base", color = Color.Red)
                }

                // Botón para comenzar grabación
                Button(
                    onClick = {
                        startRecording()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Text(text = "Comenzar Grabación", color = Color.Red)
                }

                // Botón para detener grabación
                Button(
                    onClick = {
                        stopRecording()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Text(text = "Detener Grabación", color = Color.Red)
                }
            }
        }
    }

    private fun playBeat(selectedBeat: String) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            val filePath = "${externalCacheDir?.absolutePath}/$selectedBeat"
            val audioFile = File(filePath)
            if (!audioFile.exists()) {
                Toast.makeText(this, "Archivo de audio no encontrado: $filePath", Toast.LENGTH_SHORT).show()
                return
            }

            mediaPlayer = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                start()
            }
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Error al reproducir la base", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopAudio() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        Toast.makeText(this, "Audio detenido", Toast.LENGTH_SHORT).show()
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAudioPermission()
        } else {
            audioFilePath = "${externalCacheDir?.absolutePath}/audiorecordtest.3gp"
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                setOutputFile(audioFilePath)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                try {
                    prepare()
                    start()
                    Toast.makeText(this@MainActivity, "Grabando...", Toast.LENGTH_SHORT).show()
                } catch (e: IOException) {
                    e.printStackTrace()
                    Toast.makeText(this@MainActivity, "Error al iniciar la grabación", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun stopRecording() {
        mediaRecorder?.apply {
            stop()
            release()
        }
        mediaRecorder = null
        Toast.makeText(this, "Grabación guardada en: $audioFilePath", Toast.LENGTH_SHORT).show()
    }

    private fun requestAudioPermission() {
        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (!isGranted) {
                Toast.makeText(this, "Permiso de grabación denegado", Toast.LENGTH_SHORT).show()
            }
        }

        requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
}
