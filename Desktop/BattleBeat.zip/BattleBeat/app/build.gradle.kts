plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.battlebeat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.battlebeat"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.compose.animation:animation:1.5.0") // Actualiza si es necesario
    implementation("androidx.compose.ui:ui:1.5.0") // Actualiza si es necesario
    implementation("androidx.compose.material3:material3:1.1.0") // Última versión
    implementation("androidx.compose.ui:ui-tooling-preview:1.5.0") // Última versión
    implementation("androidx.activity:activity-compose:1.7.0") // Última versión
    implementation("androidx.core:core-ktx:1.9.0") // Versión segura
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.5.1") // Versión segura
    implementation("com.google.android.material:material:1.12.0") // Última versión

    testImplementation("junit:junit:4.13.2") // JUnit para pruebas
    androidTestImplementation("androidx.test.ext:junit:1.1.3") // Pruebas de Android
    androidTestImplementation("androidx.test.espresso:espresso-core:3.4.0") // Pruebas de UI
    debugImplementation("androidx.compose.ui:ui-tooling:1.5.0") // Herramientas de depuración de Compose
    debugImplementation("androidx.compose.ui:ui-test-manifest:1.5.0") // Pruebas de manifiesto de UI
}


